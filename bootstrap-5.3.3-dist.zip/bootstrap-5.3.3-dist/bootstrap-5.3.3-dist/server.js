const express = require('express');
const path = require('path');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.static('public')); 
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', 
    database: 'personal_diet'
});

db.connect((err) => {
    if (err) {
        console.error('Errore di connessione al database:', err);
        return;
    }
    console.log('Connesso al database MySQL');

    app.listen(port, () => {
        console.log(`Server in ascolto sulla porta ${port}`);
    });
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'SitePersonalDiet.html')); 
});

app.post('/submit-data', (req, res) => {
    console.log('Corpo della richiesta POST:', req.body); 
    const { age, gender } = req.body;
    const sql = "INSERT INTO data (age, gender) VALUES (?, ?)";

    db.query(sql, [age, gender], (err, result) => {
        if (err) {
            console.error('Errore durante l\'inserimento dei dati:', err);
            res.status(500).json({ message: 'Errore durante il salvataggio dei dati' });
            return;
        }
        console.log('Dati salvati nel database', result);
        res.json({ message: 'Dati salvati con successo!' });
    });
});


app.post('/submit-weight-loss', (req, res) => {
    const { weight_loss_kg } = req.body; 

    const sql = "INSERT INTO weight_loss (weight_loss_kg) VALUES (?)";

    db.query(sql, [weight_loss_kg], (err, result) => {
        if (err) {
            console.error('Error during database insertion:', err);
            res.status(500).send({ message: 'Error saving weight loss data.' });
            return;
        }
        res.send({ message: 'Weight loss data saved successfully!' });
    });
});
